import 'package:flutter/material.dart';

class Subject {
  final String name;
  final int credits;
  final Color color;

  Subject({
    required this.name,
    required this.credits,
    required this.color,
  });
}
