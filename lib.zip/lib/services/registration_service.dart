import 'package:flutter/material.dart';

/// A small in-memory service that simulates the registration/reservation data
/// that would normally live in Firestore. This keeps the logic in one place
/// so pages/controllers can ask whether the current user is allowed to
/// register at the current time.
class RegistrationService {
  RegistrationService._private();
  static final RegistrationService instance = RegistrationService._private();

  /// Simulates a global flag in the DB that indicates whether the registration
  /// period is open. When false, students cannot create new reservations.
  bool globalRegisterOpen = true;

  // Stored as userId -> dateStr -> slot
  final Map<String, Map<String, String>> _assignedRegisterSlots = {};
  final Map<String, Map<String, String>> _reservedFreeTimes = {};

  String _dateKey(DateTime d) =>
      "${d.year}/${d.month.toString().padLeft(2, '0')}/${d.day.toString().padLeft(2, '0')}";

  /// Generate fixed registration slots between [startHour] and [endHour).
  /// Each slot is 15 minutes and formatted like "08:00 - 08:15".
  List<String> generateRegisterSlots({int startHour = 8, int endHour = 13}) {
    final slots = <String>[];
    for (var h = startHour; h < endHour; h++) {
      for (var m = 0; m < 60; m += 15) {
        final start = TimeOfDay(hour: h, minute: m);
        final endMinute = (m + 15) % 60;
        final endHourAdj = h + ((m + 15) ~/ 60);
        final end = TimeOfDay(hour: endHourAdj, minute: endMinute);
        String two(int v) => v.toString().padLeft(2, '0');
        slots.add(
          '${two(start.hour)}:${two(start.minute)} - ${two(end.hour)}:${two(end.minute)}',
        );
      }
    }
    return slots;
  }

  /// Assign an admin-provided register slot to a user for a given date.
  void assignRegisterSlotForUser(String userId, DateTime date, String slot) {
    final key = _dateKey(date);
    _assignedRegisterSlots.putIfAbsent(userId, () => {})[key] = slot;
  }

  /// Assign a free/reserved time chosen by the user (between 13:00-18:00).
  void assignFreeTimeForUser(String userId, DateTime date, String slot) {
    final key = _dateKey(date);
    _reservedFreeTimes.putIfAbsent(userId, () => {})[key] = slot;
  }

  String? getAssignedRegisterSlot(String userId, DateTime date) {
    final key = _dateKey(date);
    return _assignedRegisterSlots[userId]?[key];
  }

  String? getReservedFreeTime(String userId, DateTime date) {
    final key = _dateKey(date);
    return _reservedFreeTimes[userId]?[key];
  }

  DateTime? _parseSlotToDateTime(String slot, DateTime baseDate) {
    try {
      final parts = slot.split(' - ');
      if (parts.length != 2) return null;
      final start = parts[0];
      final startParts = start.split(':');
      final h = int.parse(startParts[0]);
      final m = int.parse(startParts[1]);
      return DateTime(baseDate.year, baseDate.month, baseDate.day, h, m);
    } catch (_) {
      return null;
    }
  }

  bool _isNowWithinSlot(String slot, DateTime now) {
    final start = _parseSlotToDateTime(slot, now);
    if (start == null) return false;
    final end = start.add(const Duration(minutes: 15));
    return now.isAtLeast(start) && now.isBefore(end);
  }

  /// Whether the given user can access the registration page at this moment.
  /// Rules implemented:
  /// - After 20:00 (8 PM) everyone can access
  /// - If the user has an assigned register slot for today and now is inside
  ///   that 15 minute window -> allow
  /// - If the user has a reserved free time for today and now is inside that
  ///   15 minute window -> allow
  bool canUserRegisterNow(String userId) {
    final now = DateTime.now();
    if (now.hour >= 20) return true;
    final date = now;
    final assigned = getAssignedRegisterSlot(userId, date);
    if (assigned != null && _isNowWithinSlot(assigned, now)) return true;
    final reserved = getReservedFreeTime(userId, date);
    if (reserved != null && _isNowWithinSlot(reserved, now)) return true;
    return false;
  }
}

extension _DateTimeComparisons on DateTime {
  bool isAtLeast(DateTime other) => !isBefore(other);
}
