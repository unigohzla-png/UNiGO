class CourseModel {
  final String title;
  final String assetPath;

  CourseModel({required this.title, required this.assetPath});
}
