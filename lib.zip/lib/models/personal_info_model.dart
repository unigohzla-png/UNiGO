class PersonalInfo {
  String address;
  String email;
  String phone;
  String altPhone;
  String identifier1;
  String identifier1Phone;
  String identifier2;
  String identifier2Phone;

  PersonalInfo({
    required this.address,
    required this.email,
    required this.phone,
    required this.altPhone,
    required this.identifier1,
    required this.identifier1Phone,
    required this.identifier2,
    required this.identifier2Phone,
  });
}
