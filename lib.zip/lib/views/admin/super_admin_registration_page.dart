import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'super_admin_student_window_page.dart';

class SuperAdminRegistrationPage extends StatefulWidget {
  const SuperAdminRegistrationPage({super.key});

  @override
  State<SuperAdminRegistrationPage> createState() =>
      _SuperAdminRegistrationPageState();
}

class _SuperAdminRegistrationPageState
    extends State<SuperAdminRegistrationPage> {
  final _db = FirebaseFirestore.instance;

  late final DocumentReference<Map<String, dynamic>> _configRef;

  bool _saving = false;

  @override
  void initState() {
    super.initState();
    _configRef = _db.collection('config').doc('registration');
  }

  Future<void> _updateConfig(Map<String, dynamic> data) async {
    setState(() => _saving = true);
    try {
      await _configRef.set(data, SetOptions(merge: true));
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Registration config updated')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text('Error: $e')));
      }
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  Future<DateTime?> _pickDateTime(DateTime initial) async {
    final date = await showDatePicker(
      context: context,
      initialDate: initial,
      firstDate: DateTime(2020),
      lastDate: DateTime(2100),
    );
    if (date == null) return null;

    final time = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.fromDateTime(initial),
    );
    if (time == null) return DateTime(date.year, date.month, date.day);

    return DateTime(date.year, date.month, date.day, time.hour, time.minute);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Registration Control')),
      body: StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
        stream: _configRef.snapshots(),
        builder: (context, snap) {
          if (snap.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          final data = snap.data?.data() ?? {};

          final bool globalOpen = (data['globalOpen'] ?? false) as bool;

          final Timestamp? startTs = data['globalStartAt'] as Timestamp?;
          final Timestamp? endTs = data['globalEndAt'] as Timestamp?;

          DateTime startAt =
              startTs?.toDate() ??
              DateTime.now().subtract(const Duration(hours: 1));
          DateTime endAt =
              endTs?.toDate() ?? DateTime.now().add(const Duration(days: 7));

          String fmt(DateTime d) =>
              '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')} '
              '${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}';

          return IgnorePointer(
            ignoring: _saving,
            child: Opacity(
              opacity: _saving ? 0.6 : 1,
              child: ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  const SizedBox(height: 16),

                  Card(
                    child: ListTile(
                      leading: const Icon(Icons.manage_accounts_outlined),
                      title: const Text('Per-student windows'),
                      subtitle: const Text(
                        'Search a student and set their window',
                      ),
                      trailing: const Icon(Icons.chevron_right),
                      onTap: () {
                        Navigator.of(context).push(
                          MaterialPageRoute(
                            builder: (_) => const SuperAdminStudentWindowPage(),
                          ),
                        );
                      },
                    ),
                  ),
                  const SizedBox(height: 16),
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            'Global registration window',
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          const SizedBox(height: 12),
                          Row(
                            children: [
                              const Text('Start:  '),
                              Expanded(
                                child: Text(
                                  fmt(startAt),
                                  style: const TextStyle(
                                    fontSize: 13,
                                    color: Colors.black87,
                                  ),
                                ),
                              ),
                              TextButton(
                                onPressed: () async {
                                  final picked = await _pickDateTime(startAt);
                                  if (picked != null) {
                                    await _updateConfig({
                                      'globalStartAt': Timestamp.fromDate(
                                        picked,
                                      ),
                                    });
                                  }
                                },
                                child: const Text('Change'),
                              ),
                            ],
                          ),
                          const SizedBox(height: 8),
                          Row(
                            children: [
                              const Text('End:   '),
                              Expanded(
                                child: Text(
                                  fmt(endAt),
                                  style: const TextStyle(
                                    fontSize: 13,
                                    color: Colors.black87,
                                  ),
                                ),
                              ),
                              TextButton(
                                onPressed: () async {
                                  final picked = await _pickDateTime(endAt);
                                  if (picked != null) {
                                    await _updateConfig({
                                      'globalEndAt': Timestamp.fromDate(picked),
                                    });
                                  }
                                },
                                child: const Text('Change'),
                              ),
                            ],
                          ),
                          const SizedBox(height: 4),
                          const Text(
                            'Students still must be within their own window (if used) '
                            'to register. This is the master on/off range.',
                            style: TextStyle(
                              fontSize: 11,
                              color: Colors.black54,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
